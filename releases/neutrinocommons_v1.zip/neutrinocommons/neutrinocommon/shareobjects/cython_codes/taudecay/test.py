import taudecay as td
td.TaudecayNeutrinos(10.0)
td.TaudecayNeutrinos(10.0,1)
