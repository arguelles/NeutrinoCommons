#ifndef __GLOBAL_H
#define __GLOBAL_H

#include "physconst.h"

PhysConst GLB_param;

#endif
