*#define WARNINGS

#define CALACC 1D-12
#define EPS 1D-20
#define ONEpEPS dcmplx(1D0, EPS)
#define ONEmEPS dcmplx(1D0, -EPS)
#define IEPS dcmplx(0D0, EPS)

#define CHECK
