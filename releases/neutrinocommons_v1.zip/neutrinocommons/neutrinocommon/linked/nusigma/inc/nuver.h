*          -*- mode: fortran -*-
      character*128 nudir
      character*40 nuversion
      integer nri
      common/nuver/nudir,nuversion,nri
      save /nuver/

